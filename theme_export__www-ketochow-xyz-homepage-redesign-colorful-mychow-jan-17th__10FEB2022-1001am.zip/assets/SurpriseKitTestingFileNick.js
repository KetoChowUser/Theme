/* Clara's team testing a fix

console.log(5 + 6);
classname.addEventListener('rb-footer-actions', skipStep(), false); //listens for click on class
var myFunction = skipStep() {
var bodyId = document.getElementsByTagName("body")[0].id;

//if statement for if body tag matches mychow-surprise-kit-subscription-testing

if (bodyId = 'mychow-surprise-kit-subscription-testing') {
document.querySelectorAll('.btn,.rb-btn,.rb-btn-add')
document.querySelectorAll('.btn,.rb-btn,.rb-btn-remove')
}
  
 /* Zeke's 

var foo = document.getElementsByClassName("rb-btn-add");
var baz = document.getElementsByClassName("rb-btn-remove");

var myFunction = function() {
  if (bodyId = 'mychow-surprise-kit-subscription-testing'){
    document.querySelectorAll('.btn,.rb-btn,.rb-btn-add')
	document.querySelectorAll('.btn,.rb-btn,.rb-btn-remove')
  };
};

for (var i = 0; i < elements.length; i++) {
    elements[i].addEventListener('click', myFunction, false);
};
  
  
  
};*/

console.log(5 + 6);
classname.addEventListener('rb-footer-actions', skipStep(), true); //listens for click on class
var myFunction = skipStep() {
var bodyId = document.getElementsByTagName("body")[0].id;

//if statement for if body tag matches mychow-surprise-kit-subscription-testing

if (bodyId = 'mychow-surprise-kit-subscription-testing') {
document.querySelectorAll('.btn,.rb-btn,.rb-btn-add')
document.querySelectorAll('.btn,.rb-btn,.rb-btn-remove')
}
  
};