var imported=document.createElement("script");imported.src="https://apis.google.com/js/platform.js?onload=renderBadge";document.head.appendChild(imported);window.___gcfg={lang:"en-US"};
